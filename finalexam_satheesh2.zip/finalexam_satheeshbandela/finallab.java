package Finaltest;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class finallab
{
	public static WebDriver driver;
	@Test(priority=1)
	public  void launchingBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\2093710.MATRIXCOLLEGE\\Downloads\\chromedriver.exe");
		 driver= new ChromeDriver();
	}
	@Test(priority=2)
	public void login()
	{
		driver.get("https://www.saucedemo.com/");
		driver.findElement(By.name("user-name")).sendKeys("standard_user"+Keys.TAB+"secret_sauce"+Keys.ENTER);
		}
	@Test(priority=3)
	public void buyProduct()
	{
	
		driver.findElement(By.name("add-to-cart-sauce-labs-backpack")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.findElement(By.className("shopping_cart_badge")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("checkout")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.id("first-name")).sendKeys("Satheesh"+Keys.TAB+"Bandela"+Keys.TAB+"H3T1E8");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("continue")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("finish")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("back-to-products")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Program execueted successfully");
	}
	}